<?php
/*
Plugin Name: Zefir Shortcodes (shared on wplocker.com)
Plugin URI: http://birdwp.com
Description: Available shortcodes: Text columns, Information boxes, Highlight, Buttons, Dividers, Font Awesome Icons, Tabs, Toggle and Accordion.
Author: Alexey Trofimov
Version: 1.0
Author URI: http://themeforest.net/user/BirdwpThemes
*/

/**
 * Changelog:
 *
 * 1.0
 * - Initial release
 */

if (!defined('ABSPATH')) {
  die('Hi there!  I\'m just a plugin...');
}

/**
 * Add shortcodes button to the wp editor
 *
 * @since Zefir Shortcodes 1.0
 * @access public
 * @return void
 */
if (!function_exists('zefir_sc_add_button')) {
  function zefir_sc_add_button() {
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
      return;
    }

    if (get_user_option('rich_editing') == 'true') {
      add_filter('mce_external_plugins', 'zefir_sc_tinymce_plugin');
      add_filter('mce_buttons', 'zefir_sc_register_new_button');
    }
  }
}
add_action('init', 'zefir_sc_add_button');

/**
 * Add shortcodes button to TinyMCE
 *
 * @since Zefir Shortcodes 1.0
 * @access public
 * @param $plugin_array
 * @return array
 */
function zefir_sc_tinymce_plugin($plugin_array) {
  $plugin_array['zefirShortcodes'] = plugins_url('js/tinymce-plugin.js', __FILE__);
  return $plugin_array;
}

/**
 * Register new button
 *
 * @since Zefir Shortcodes 1.0
 * @access public
 * @param $buttons
 * @return array
 */
function zefir_sc_register_new_button($buttons) {
  array_push($buttons, "|", "zefir_shortcodes_button");
  return $buttons;
}

/**
 * Add shortcode button style
 *
 * @since Zefir Shortcodes 1.0
 * @access public
 * @return void
 */
if (!function_exists('zefir_sc_button_style')) {
  function zefir_sc_button_style() {
    if (is_admin()) {
      $btn_style_url = plugins_url('css/shortcodes_button.css', __FILE__);
      wp_enqueue_style('zefir-sc-tinymce-btn-style', $btn_style_url, '', '', 'all');
    }
  }
}
add_action('admin_enqueue_scripts', 'zefir_sc_button_style');

/**
 * Refresh TinyMCE ver
 *
 * @since Zefir Shortcodes 1.0
 * @access public
 * @param $ver
 * @return int
 */
if (!function_exists('zefir_sc_refresh_mce_ver')) {
  function zefir_sc_refresh_mce_ver($ver) {
    $ver += 3;
    return $ver;
  }
}
add_filter('tiny_mce_version', 'zefir_sc_refresh_mce_ver');

/**
 * Add shortcodes
 */
require_once('shortcodes.php');
